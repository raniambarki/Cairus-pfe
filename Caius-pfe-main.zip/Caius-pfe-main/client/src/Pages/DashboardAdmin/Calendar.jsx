import Page from '../../Layouts/LayoutPage'
import Calender from '../../Components/DashboardAdmin/Calender'

export default function Calendar() {
    return (
        <Page
            title="Calendrier"
            content={< Calender />}
        />
    )
}
