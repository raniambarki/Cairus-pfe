
import Visio from '../../Components/Visio/Visio'
import Page from '../../Layouts/LayoutPage'

function Call() {


    return (
        <>

            <Page
                title="Visioconférence"
                content={<Visio />}
            />
        </>
    )
}
export default Call

