import Events from '../../Components/Dashboard/Events'
import Page from '../../Layouts/LayoutPage'

function Expert() {
    return (
        <Page
            title="Nos Events & Formation"
            content={< Events />}
        />
    )
}
export default Expert

