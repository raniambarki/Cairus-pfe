import Experts from '../../Components/Dashboard/Experts'
import Page from '../../Layouts/LayoutPage'

function Expert() {
    return (
        <Page
            title="Contacter un expert"
            content={< Experts />}
        />
    )
}
export default Expert

