import Page from '../../Layouts/LayoutPage'
import CTA from '../../Components/DashboardDefault/CTA'
function Autre() {
    return (
        <Page
            content={< CTA />}
        />
    )
}
export default Autre

