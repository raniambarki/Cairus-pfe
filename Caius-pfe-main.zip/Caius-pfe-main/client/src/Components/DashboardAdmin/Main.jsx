import Stats from '../Stats/StatsAdmin'

function Main() {

    return (

        <>
            <section className="text-gray-600 body-font">

                <Stats />

            </section>
        </>
    )
}
export default Main