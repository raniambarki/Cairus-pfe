import Render from './Routes/Routes'

export default function App() {
  return (
    <>
      <Render />
    </>
  )
}